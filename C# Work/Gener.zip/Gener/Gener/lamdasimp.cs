﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Gener
//{
//    internal class lamdasimp
//    {
//        public delegate int info(int a);
//        public static void Main(string[] args)
//        {
//            //info o = (a) => a + a;

//            //    Console.WriteLine(o.Invoke(5));

//            info o = (a) => a += a;
            

//            Console.WriteLine(o(87));
//        }
//    }
//}
