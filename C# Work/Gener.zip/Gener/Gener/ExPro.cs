﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gener
{
     class ExPro
    {
        public static void Main()
        {
            Exfun e = new Exfun();
            e.Fun3();
            e.Fun1();
            e.Fun2();
            e.Fun4(80);
            
        }
    }
}
