﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Gener
//{
//    internal class indexr
//    {
//        private int[] nm = new int[3];

//        public int this[int index]
//        {
//            set
//            {
//                nm[index] = value;
//            }
//            get
//            {
//                return nm[index];
//            }
//        }

//        public static void Main(string[] args)
//        {
//            indexr o = new indexr();
//            o[0] = 5;
//            Console.WriteLine(o[0]);
//        }
//    }
//}
