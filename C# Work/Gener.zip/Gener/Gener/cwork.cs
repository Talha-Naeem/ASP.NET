﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Gener
//{
//    public class cwork<T>
//    {
//        T Id;
//        //T Name;

//        public T GetID
//        {
//            set {
//                this.Id = value;
//            }
//            get
//            {
//                return this.Id;
//            }
//        }
//    }
//    class Pro
//        {
//           public  static void Main(string[] args)
//            {
//                cwork<int> g = new cwork<int>();
//            g.GetID = 20;
//            Console.WriteLine(g.GetID);

//            }
//        }
    
//}

