﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gener
{  
    static class ExMe
    {
      
        public static void Fun3(this Exfun e)
        {
            Console.WriteLine("klmn sdffg");
        }

        public static void Fun4(this Exfun e,int i)
        {
            Console.WriteLine("klmn sdffg  " + i);
        }
    }
}
