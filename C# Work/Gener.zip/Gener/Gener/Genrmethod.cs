﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Gener
//{
//    internal class Genrmethod
//    {
//        public static void GetName<T>(T[] arr)
//        {
//            for (int i = 0; i < arr.Length; i++)
//            {
//                Console.WriteLine(arr[i]);
//            }
//        }
//        public static bool Check<T>(T a,T b)
//        {
//            bool c;
//             c = a.Equals(b);
//            return c;
//        }
//    public static void Main(string[] args)
//        {
//            int[] Numbers = { 14, 15, 16 };
//            string[] names = new string[3];
//            names[0] = "Tal";
//            names[1] = "Fti";
//            names[2] = "tfi";

//            double[] poin = new double[2];
//            poin[0] = 1.9;
//            poin[1] = 2.4;

//            Genrmethod.GetName(Numbers);
//            Console.WriteLine(" ------------");
//            Genrmethod.GetName(names);
//            Console.WriteLine(" ------------");
//            Genrmethod.GetName(poin);

//            Console.WriteLine(" ------------");
//            Console.WriteLine(Genrmethod.Check(10, 01));

//            Console.WriteLine(" ------------");
//            Console.WriteLine(Genrmethod.Check("Ali", "Ali"));

//            Console.WriteLine(" ------------");
//            Console.WriteLine(Genrmethod.Check("Ali", "ali"));

//            Console.WriteLine(" ------------");
//            Console.WriteLine(Genrmethod.Check('f', 'F'));
//        }
//    }
//}
