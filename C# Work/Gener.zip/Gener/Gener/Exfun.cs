﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gener
{
        //sealed class or struct class kylye beh extension used hotay hain
    internal class Exfun
    {
        public void Fun1()
        {
            Console.WriteLine("as dfg klo");
        }
        public void Fun2()
        {
            Console.WriteLine("as  klo");
        }
        public static void Main(string[] args)
        {
            Exfun e = new Exfun();
            //e.Fun1();
            //e.Fun2();
            //e.Fun3();
        }
    }
}
