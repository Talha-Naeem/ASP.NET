﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Gener
//{
//    public delegate void GetInfo(int a, int b);
//    public delegate void GetS();
//    public class Delg
//    {
        
//        public static void GetAdd(int a,int b)
//        {
//            int c;
//            c = a + b;
//            Console.WriteLine("hjkk "+c);
//        }
//        public static void GetSub(int a, int b)
//        {
//            int c;
//            c = a - b;
//            Console.WriteLine("hjkk " + c);
//        }
//        public static void GetMult(int a, int b)
//        {
//            int c;
//            c = a * b;
//            Console.WriteLine("hjkk " + c);
//        }
//        public static void GetDiv(int a, int b)
//        {
//            int c;
//            c = a / b;
//            Console.WriteLine("hjkk " + c);
//        }
//        public static void GetSu()
//        {
//            //int a;int b; int c;
//            //c = a + b;
//            Console.WriteLine("dsffvv ");
//        }
//        public static void Main(string[] args)
//        {
//            GetInfo o = new GetInfo(Delg.GetAdd);
//            o.Invoke(2,5);
//            o = GetSub; 
//            o(2, 5);
//            o = GetMult;
//            o(2, 5);
//            o = GetDiv;
//            o(2, 5);

//            GetInfo oo = new GetInfo(Delg.GetMult);
//            oo.Invoke(2, 5);
//            GetInfo o2 = new GetInfo(Delg.GetSub);
//            o2.Invoke(2, 5);

//            GetS o1 = new GetS(Delg.GetSu);
//            o1.Invoke();
//            Delg.GetSub(20, 90);
//        }
//    }
//}