﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Gener
//{
//    static class stati
//    {
//        public static int a;
//        public static int b;

//         static stati()
//        {
//            a = 10;
//            b = 20;
//        }
//        public static void info()
//        {
//            Console.WriteLine("hj kkkl ssjj");
//        }

//        public static void inf()
//        {
//            a = 1;
//            Console.WriteLine(a);
//        }
//        public static void infi()
//        {
            
//            Console.WriteLine(a);
//            Console.WriteLine(b);
//        }

//        public static void Main(string[] args)
//        {
//            stati.info();
//            stati.infi();
//        }
//    }
//}
