﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SRP
{
    internal interface IUser
    {
        bool Login(string username, string password);
        bool Register(string username, string password, string email);

        //void Logger(string error);

        //bool Email(string emailcontent);
    }
    interface ILogger
    {
        void LogError(string error);
    }

    interface IEmail
    {
        bool LogError(string emailcontent);
    }

}
