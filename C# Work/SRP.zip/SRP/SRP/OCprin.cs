﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SRP
{
    abstract class OCprin
    {
        public abstract double CalculateBonus(double salary);
    }
    class PermanentEmp :OCprin
    {
        public override double CalculateBonus(double salary)
        {
            return ((salary * 0.2) / 100);
        }
    }
    class ContractEmp : OCprin
    {
        public override double CalculateBonus(double salary)
        {
            return 0;
        }
    }

    class ThirdPartyEmp : OCprin
    {
        public override double CalculateBonus(double salary)
        {
            return ((salary * 0.1) / 100);
        }
    }
}
