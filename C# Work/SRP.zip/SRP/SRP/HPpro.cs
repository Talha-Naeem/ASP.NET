﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SRP
{
    internal class HPpro : ISP,IBluetooth
    {
        public void BlackPrint(string content)
        {
            content = "Black & White print ";
            Console.WriteLine(content);
        }

        public void ColorPrint(string content)
        {
            content = "Color print ";
            Console.WriteLine(content);
        }

        public void PhotoCopy(string content)
        { 
            content = "PhotoCopy print ";
            Console.WriteLine(content);
        }
        public void Bluetooth(string conn)
        {
            conn = "Bluetooth Connecting ";
            Console.WriteLine(conn);
        }
    }
    class Canvapro : ISP
    {
        public void BlackPrint(string content)
        {
            content = "Black & White print ";
            Console.WriteLine(content);
        }

        public void ColorPrint(string content)
        {
            content = "Color print ";
            Console.WriteLine(content);
        }

        public void PhotoCopy(string content)
        {
            content = "PhotoCopy print ";
            Console.WriteLine(content);
        }
    }
}
