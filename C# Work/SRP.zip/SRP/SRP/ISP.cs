﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SRP
{
    internal interface ISP
    {
        void BlackPrint(string content);
        void ColorPrint(string content);

        void PhotoCopy(string content);

    }
    interface IBluetooth
    {
        void Bluetooth(string conn);
    }
}
