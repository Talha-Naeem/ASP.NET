﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryPat
{
    internal class Oracle :IDatabase
    {
        public void Connect()
        {
            Console.WriteLine("Oracle is connected");
        }
    }
}
