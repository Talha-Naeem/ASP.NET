﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryPat
{
    internal class DatabaseFactory
    {
        public IDatabase GetDatabase(string sdatabase)
        {
            switch (sdatabase)
            {
                case "sql":
                    return new Sql();
                case "oracle":
                    return new Oracle();
                case "mysql":
                    return new MySql();
                default:
                    return null;
            }
        }
    }
}
