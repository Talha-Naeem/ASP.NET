﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryPat
{
    class Program
    {
        public static void Main(string[] args)
        {
            DatabaseFactory myFactory = new DatabaseFactory();
            string databasetype = "sql";
            IDatabase database = myFactory.GetDatabase(databasetype);
            database.Connect();

        }
    }
}